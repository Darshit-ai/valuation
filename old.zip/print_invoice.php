<?php
include 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_GET['id'])) {
    $_SESSION['error'] = 'No valuation ID provided.';
    header('Location: valuations_list.php');
    exit;
}

$valuation_id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM valuations WHERE id = ?");
$stmt->execute([$valuation_id]);
$valuation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$valuation) {
    $_SESSION['error'] = 'Valuation not found.';
    header('Location: valuations_list.php');
    exit;
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>
<div class="print-watermark">Gulf Adjusters, Surveyors & Services LLC</div>
<style>
@media screen {
    .print-watermark {
        display: none;
    }
}
@media print {
    .print-watermark {
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        height: 100% !important;
        width: 100% !important;
        font-size: 72px !important;
        color: rgba(0, 0, 0, 0.08) !important;
        font-weight: bold !important;
        z-index: 9999 !important;
        pointer-events: none !important;
        transform: rotate(-45deg) !important;
        white-space: nowrap !important;
    }
}
</style>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Tax Invoice</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Invoice Details</h3>
                    <div class="card-tools">
                        <button class="btn btn-primary no-print" onclick="window.print()">Print Invoice</button>
                    </div>
                </div>
                <div class="card-body printable">
                    <h4>TAX INVOICE</h4>
                    <p>----------------------------</p>
                    <p class="bold">REF: GAS/VAL/2023/IMP/DATE: 04/10/2023</p>
                    <p>To,</p>
                    <p>VATIN: </p>
                    <p>P.O.BOX-1120, P.C-133,</p>
                    <p>Al Khuwair</p>
                    <p>Sultanate Of Oman.</p>
                    <h4>RE: Valuation Report For Caterpillar Dozer</h4>
                    <p>-------------------------------------------------------------------------</p>
                    <p>Valuation fees as agreed LS R.O.     .000</p>
                    <p>VAT 5% R.O.       2.500</p>
                    <p>---------------------</p>
                    <p class="bold">Total Due                                   R.O.    </p>
                    <p class="bold">                ===============</p>
                    <p>(Rials Omani Fifty Two and Baizas 500/1000 Only)</p>
                    <p class="bold">Kindly arrange to transfer fees to our following account details: </p>
                    <p>Gulf Adjusters, Surveyors & Services LLC</p>
                    <p>Bank Muscat SAOG</p>
                    <p>Corporate Branch</p>
                    <p>Current A/c No.: 0423 01090820 0014</p>
                    <p class="bold">For GULF ADJUSTERS, SURVEYORS & SERVICES LLC</p>
                    <p class="bold">Finance Executive</p>
                </div>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>
